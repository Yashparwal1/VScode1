import requests
from bs4 import BeautifulSoup
URL = "https://github.com/projectdiscovery/nuclei"
print("please wait..\r",end="")
r = requests.get(URL)
soup = BeautifulSoup(r.content, 'html5lib')
paras = soup.select('p[dir="auto"]')
print(paras[3].text)
